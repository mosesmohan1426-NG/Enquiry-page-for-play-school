/* =============================================
   LITTLE ROSES PLAY SCHOOL — main.js
   Features:
   - Preloader
   - Particle canvas background
   - Navbar scroll + mobile hamburger
   - Counter animation
   - Scroll reveal
   - Gallery filter + lightbox
   - Testimonial slider
   - Form → Google Sheets (SheetDB/Apps Script)
   - Scroll-to-top button
   ============================================= */

/* ── GOOGLE SHEETS CONFIG ─────────────────────
   IMPORTANT: Replace the URL below with your
   own Google Apps Script Web App URL.
   See README.md for full setup instructions.
─────────────────────────────────────────────── */
const SHEETS_URL = "https://script.google.com/macros/s/AKfycby7ulFTHiZ1BzX1k00JG5H_MkT-whG1WwGiC6EIFqdi0PMvyzdWgND7AA2wsBM7_h2s/exec";
// Example: "https://script.google.com/macros/s/XXXXXXXXXX/exec"

/* ── PRELOADER ─────────────────────────────── */
window.addEventListener("load", () => {
  setTimeout(() => {
    document.getElementById("preloader").classList.add("done");
  }, 1900);
});

/* ── PARTICLES CANVAS ──────────────────────── */
(function () {
  const canvas  = document.getElementById("particles");
  const ctx     = canvas.getContext("2d");
  let   W, H, particles = [];

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener("resize", resize);

  class Particle {
    constructor() { this.reset(); }
    reset() {
      this.x  = Math.random() * W;
      this.y  = Math.random() * H;
      this.r  = Math.random() * 2.5 + 0.5;
      this.dx = (Math.random() - 0.5) * 0.4;
      this.dy = (Math.random() - 0.5) * 0.4;
      this.a  = Math.random() * 0.5 + 0.1;
    }
    update() {
      this.x += this.dx; this.y += this.dy;
      if (this.x < 0 || this.x > W || this.y < 0 || this.y > H) this.reset();
    }
    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(21,101,192,${this.a})`;
      ctx.fill();
    }
  }

  for (let i = 0; i < 80; i++) particles.push(new Particle());

  // Draw connecting lines
  function drawLines() {
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 120) {
          ctx.beginPath();
          ctx.strokeStyle = `rgba(21,101,192,${0.08 * (1 - dist / 120)})`;
          ctx.lineWidth = 0.5;
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
        }
      }
    }
  }

  function loop() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => { p.update(); p.draw(); });
    drawLines();
    requestAnimationFrame(loop);
  }
  loop();
})();

/* ── NAVBAR ────────────────────────────────── */
const navbar    = document.getElementById("navbar");
const hamburger = document.getElementById("hamburger");
const navLinks  = document.getElementById("navLinks");

window.addEventListener("scroll", () => {
  navbar.classList.toggle("scrolled", window.scrollY > 50);
  document.getElementById("scrollTop").classList.toggle("show", window.scrollY > 400);
});

hamburger.addEventListener("click", () => {
  navLinks.classList.toggle("open");
  const bars = hamburger.querySelectorAll("span");
  const open = navLinks.classList.contains("open");
  bars[0].style.transform = open ? "rotate(45deg) translate(5px,6px)" : "";
  bars[1].style.opacity   = open ? "0" : "";
  bars[2].style.transform = open ? "rotate(-45deg) translate(5px,-6px)" : "";
});

navLinks.querySelectorAll("a").forEach(a => {
  a.addEventListener("click", () => {
    navLinks.classList.remove("open");
    hamburger.querySelectorAll("span").forEach(b => { b.style.transform = ""; b.style.opacity = ""; });
  });
});

/* ── ACTIVE NAV LINK ───────────────────────── */
const navAs    = document.querySelectorAll(".nav-a");
const sections = document.querySelectorAll("section[id]");

new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      navAs.forEach(a => a.classList.remove("active"));
      const active = document.querySelector(`.nav-a[href="#${e.target.id}"]`);
      if (active) active.classList.add("active");
    }
  });
}, { rootMargin: "-40% 0px -50% 0px" }).observe
// Actually observe each section
sections.forEach(s =>
  new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        navAs.forEach(a => a.classList.remove("active"));
        const active = document.querySelector(`.nav-a[href="#${e.target.id}"]`);
        if (active) active.classList.add("active");
      }
    });
  }, { rootMargin: "-40% 0px -50% 0px" }).observe(s)
);

/* ── SCROLL REVEAL ─────────────────────────── */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      // Stagger cards
      if (entry.target.classList.contains("reveal-card")) {
        const siblings = entry.target.parentElement.querySelectorAll(".reveal-card");
        let idx = 0;
        siblings.forEach((s, j) => { if (s === entry.target) idx = j; });
        entry.target.style.transitionDelay = `${idx * 0.1}s`;
      }
      entry.target.classList.add("revealed");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll(".reveal-section, .reveal-left, .reveal-right, .reveal-card")
  .forEach(el => revealObserver.observe(el));

/* ── COUNTER ANIMATION ─────────────────────── */
let countersStarted = false;

function animateCounters() {
  if (countersStarted) return;
  document.querySelectorAll(".hstat-n[data-count]").forEach(el => {
    const target = +el.dataset.count;
    let current  = 0;
    const step   = target / 60;
    const timer  = setInterval(() => {
      current += step;
      if (current >= target) { el.textContent = target; clearInterval(timer); }
      else el.textContent = Math.floor(current);
    }, 25);
  });
  countersStarted = true;
}

new IntersectionObserver(entries => {
  if (entries[0].isIntersecting) animateCounters();
}, { threshold: 0.3 }).observe(document.querySelector(".hero-stats"));

/* ── GALLERY FILTER ────────────────────────── */
const gtabs  = document.querySelectorAll(".gtab");
const gitems = document.querySelectorAll(".gi");

gtabs.forEach(tab => {
  tab.addEventListener("click", () => {
    gtabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    const cat = tab.dataset.cat;
    gitems.forEach(item => {
      const match = cat === "all" || item.dataset.cat === cat;
      item.classList.toggle("gone", !match);
      if (match) item.style.animation = "revealItem .4s ease both";
    });
  });
});

const styleEl = document.createElement("style");
styleEl.textContent = `
@keyframes revealItem {
  from{opacity:0;transform:scale(.92);}
  to{opacity:1;transform:scale(1);}
}`;
document.head.appendChild(styleEl);

/* ── LIGHTBOX ──────────────────────────────── */
const lightbox = document.getElementById("lightbox");
const lbImg    = document.getElementById("lbImg");
const lbClose  = document.getElementById("lbClose");
const lbPrev   = document.getElementById("lbPrev");
const lbNext   = document.getElementById("lbNext");
let   lbIndex  = 0, lbImgs = [];

function openLB(idx) {
  lbImgs = [...document.querySelectorAll(".gi:not(.gone) img")];
  lbIndex = idx;
  lbImg.src = lbImgs[lbIndex].src;
  lightbox.classList.add("open");
  document.body.style.overflow = "hidden";
}
function closeLB() {
  lightbox.classList.remove("open");
  document.body.style.overflow = "";
}
function stepLB(dir) {
  lbIndex = (lbIndex + dir + lbImgs.length) % lbImgs.length;
  lbImg.style.opacity = "0";
  setTimeout(() => {
    lbImg.src = lbImgs[lbIndex].src;
    lbImg.style.opacity = "1";
  }, 150);
}

gitems.forEach((item, i) => {
  item.addEventListener("click", () => {
    const visible = [...document.querySelectorAll(".gi:not(.gone)")];
    openLB(visible.indexOf(item));
  });
});
lbClose.addEventListener("click", closeLB);
lightbox.addEventListener("click", e => { if (e.target === lightbox) closeLB(); });
lbNext.addEventListener("click", () => stepLB(1));
lbPrev.addEventListener("click", () => stepLB(-1));
document.addEventListener("keydown", e => {
  if (!lightbox.classList.contains("open")) return;
  if (e.key === "Escape")      closeLB();
  if (e.key === "ArrowRight")  stepLB(1);
  if (e.key === "ArrowLeft")   stepLB(-1);
});

/* ── TESTIMONIAL SLIDER ────────────────────── */
const track = document.getElementById("testiTrack");
const dots  = document.querySelectorAll(".tdot");
let   tIdx  = 0, tAuto;

function goTo(idx) {
  tIdx = (idx + dots.length) % dots.length;
  track.style.transform = `translateX(-${tIdx * (100 / dots.length)}%)`;
  dots.forEach((d, i) => d.classList.toggle("active", i === tIdx));
}

dots.forEach((dot, i) => dot.addEventListener("click", () => { goTo(i); resetAuto(); }));

function resetAuto() { clearInterval(tAuto); tAuto = setInterval(() => goTo(tIdx + 1), 5000); }
resetAuto();

// Touch swipe support
let tStart = 0;
track.addEventListener("touchstart",  e => { tStart = e.touches[0].clientX; });
track.addEventListener("touchend",    e => {
  const diff = tStart - e.changedTouches[0].clientX;
  if (Math.abs(diff) > 50) { goTo(tIdx + (diff > 0 ? 1 : -1)); resetAuto(); }
});

/* ── ENQUIRY FORM → GOOGLE SHEETS ─────────── */
const form       = document.getElementById("enquiryForm");
const btnText    = document.getElementById("btnText");
const btnLoader  = document.getElementById("btnLoader");
const formSuccess= document.getElementById("formSuccess");

form && form.addEventListener("submit", async (e) => {
  e.preventDefault();

  // Show loader
  btnText.classList.add("hidden");
  btnLoader.classList.remove("hidden");

  const data = {
    timestamp:   new Date().toLocaleString("en-IN"),
    parentName:  form.parentName.value.trim(),
    childName:   form.childName.value.trim(),
    childAge:    form.childAge.value,
    program:     form.program.value,
    email:       form.email.value.trim(),
    phone:       form.phone.value.trim(),
    message:     form.message.value.trim()
  };

  // ----- SEND TO GOOGLE SHEETS -----
  // Only attempt if URL is configured
  const isConfigured = SHEETS_URL && !SHEETS_URL.includes("YOUR_GOOGLE");

  if (isConfigured) {
    try {
      // Google Apps Script requires no-cors mode
      await fetch(SHEETS_URL, {
        method:  "POST",
        mode:    "no-cors",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(data)
      });
    } catch (err) {
      console.warn("Sheets submission error:", err);
    }
  }

  // ----- ALSO SEND TO NETLIFY FORMS (backup) -----
  try {
    const netlifyData = new URLSearchParams({ "form-name": "admission", ...data });
    await fetch("/", {
      method:  "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body:    netlifyData.toString()
    });
  } catch (_) { /* netlify optional */ }

  // Show success
  form.classList.add("hidden");
  formSuccess.classList.remove("hidden");
});

window.resetForm = function() {
  form.reset();
  form.classList.remove("hidden");
  formSuccess.classList.add("hidden");
  btnText.classList.remove("hidden");
  btnLoader.classList.add("hidden");
};

/* ── SCROLL TO TOP ─────────────────────────── */
document.getElementById("scrollTop").addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

/* ── LOGO ERROR FALLBACK ───────────────────── */
document.querySelectorAll('img[src="images/logo.jpg"]').forEach(img => {
  img.addEventListener("error", () => { img.style.display = "none"; });
});
