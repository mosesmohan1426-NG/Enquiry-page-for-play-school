/**
 * ================================================
 * GOOGLE APPS SCRIPT — Little Roses Enquiry Form
 * ================================================
 * PASTE THIS CODE into your Google Apps Script editor.
 * See README.md for full step-by-step instructions.
 */

// 📌 STEP 1: Open a new Google Sheet
// 📌 STEP 2: Go to Extensions > Apps Script
// 📌 STEP 3: Paste this entire file and click Save
// 📌 STEP 4: Click Deploy > New Deployment > Web App
// 📌 STEP 5: Set "Who has access" to "Anyone"
// 📌 STEP 6: Copy the Web App URL and paste into js/main.js

function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Add header row if sheet is empty
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        "S.No",
        "Timestamp",
        "Parent Name",
        "Child Name",
        "Child Age",
        "Program",
        "Email",
        "Phone",
        "Message",
        "Status"
      ]);
      
      // Style header row
      var header = sheet.getRange(1, 1, 1, 10);
      header.setBackground("#1565C0");
      header.setFontColor("#FFFFFF");
      header.setFontWeight("bold");
      header.setFontSize(11);
    }
    
    // Parse the incoming JSON data
    var data = JSON.parse(e.postData.contents);
    
    // Get row number
    var rowNum = sheet.getLastRow();
    
    // Append new row with form data
    sheet.appendRow([
      rowNum,                         // S.No (auto)
      data.timestamp   || new Date().toLocaleString("en-IN"),
      data.parentName  || "",
      data.childName   || "",
      data.childAge    || "",
      data.program     || "",
      data.email       || "",
      data.phone       || "",
      data.message     || "",
      "New Enquiry"                   // Status column (for your tracking)
    ]);
    
    // Auto-resize columns for readability
    sheet.autoResizeColumns(1, 10);
    
    // Optional: Send email notification to school
    sendEmailNotification(data);
    
    // Return success response
    return ContentService
      .createTextOutput(JSON.stringify({ success: true, message: "Enquiry saved!" }))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    Logger.log("Error: " + error.toString());
    return ContentService
      .createTextOutput(JSON.stringify({ success: false, error: error.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ── EMAIL NOTIFICATION (optional) ──────────────
function sendEmailNotification(data) {
  try {
    var SCHOOL_EMAIL = "info@littleroses.edu.in"; // 📌 Change to your email
    
    var subject = "🌹 New Admission Enquiry — " + data.childName + " (" + data.childAge + ")";
    
    var body = `
Hello Little Roses Team,

A new admission enquiry has been submitted via your website.

━━━━━━━━━━━━━━━━━━━━
ENQUIRY DETAILS
━━━━━━━━━━━━━━━━━━━━
Parent Name  : ${data.parentName}
Child Name   : ${data.childName}
Child's Age  : ${data.childAge}
Program      : ${data.program}
Email        : ${data.email}
Phone        : ${data.phone}
Message      : ${data.message || "—"}
Submitted At : ${data.timestamp}
━━━━━━━━━━━━━━━━━━━━

Please follow up within 24 hours.

— Little Roses Website Notification
    `;
    
    MailApp.sendEmail(SCHOOL_EMAIL, subject, body);
  } catch (err) {
    Logger.log("Email error: " + err.toString());
    // Don't fail the whole function if email fails
  }
}

// ── Handle GET requests (test the endpoint) ────
function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({
      status:  "Little Roses Enquiry API is running!",
      school:  "Little Roses Play School",
      contact: "info@littleroses.edu.in"
    }))
    .setMimeType(ContentService.MimeType.JSON);
}
